/**
 * 
 */
package com.oracle.automationpractice.commonlibrary;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

/**
 * @author Prateek Shrivastava
 *
 */
public class BaseClass {

	public WebDriver driver;
	static String path = "resources/config.properties";

	/**
	 * to set the browser
	 * 
	 * @param type
	 */
	@BeforeClass
	public void setupApplication() {
		LoadConfigurationPropertyUtility.readFile(path);

		if (LoadConfigurationPropertyUtility.browser.equalsIgnoreCase("chrome")) {

			System.setProperty("webdriver.chrome.driver", "resources\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (LoadConfigurationPropertyUtility.browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", "resources\\geckodriver.exe");
			driver = new FirefoxDriver();

		}

		driver.get(LoadConfigurationPropertyUtility.url);

		// Resize current window to the set dimension
		driver.manage().window().maximize();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

	}
	
	
	  @AfterClass public void closebrowser() { driver.close(); }
	  

		
	
}
