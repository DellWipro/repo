package com.oracle.automationpractice.commonlibrary;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

public class LoadConfigurationPropertyUtility {
	
	public static String emailId;
	public static String password;
	public static String url;
	public static String browser;
	
	public static void writeFile(String emailId,String password, String path ) {
	    try {
	    	FileOutputStream output = new FileOutputStream (path);
	    	
	    	FileInputStream in = new FileInputStream(path);
	        Properties prop = new Properties();
	
	        prop.load(in);
	        in.close();
	        
	        // set the properties value
	        prop.setProperty("emailId", emailId);
	        prop.setProperty("password", password);
	        // save properties to project root folder
	       prop.store(output, null);
	
	        System.out.println("Common Function write "+prop);
	        output.close();
	
	    } catch (IOException io) 
	    {
	        io.printStackTrace();
	}
	}

	
	public static void readFile(String path) {
		
		try {
		InputStream input = new FileInputStream(path) ;

            Properties prop = new Properties();

            // load a properties file
            prop.load(input);

            // get the property value and print it out
            emailId=prop.getProperty("emailId");
            password=prop.getProperty("password");
            url=prop.getProperty("url");
            browser=prop.getProperty("browser");
            System.out.println("Common Function read "+prop);

        } 
		catch (IOException ex) {
            ex.printStackTrace();
        }
	}
}
