package com.oracle.automationpractice.dataprovider;

import java.util.Random;

import org.testng.annotations.DataProvider;

import com.oracle.automationpractice.commonlibrary.LoadConfigurationPropertyUtility;

public class RegistrationDataProvider {
	
static String  path ="resources/login.properties";
	
	@DataProvider(name = "registration")
	public static Object[][] getRegistrationData() {
	
	Random rand = new Random();
	//Rows - Number of times your test has to be repeated.
	//Columns - Number of parameters in test data.
	Object[][] data = new Object[1][9];

	// First Name
	data[0][0] ="Prateek";
	
	//Second Name
	data[0][1] = "Shrivastava";

	//Email
	data[0][2] = "prateek"+ rand.nextInt((999 - 100) + 1) + 1000+"@gmail.com";
	
	//Password
	data[0][3] = "Test@123";	
	LoadConfigurationPropertyUtility.writeFile((String)data[0][2],(String) data[0][3],path);
	
	//Address
	
	data[0][4] = "HSR Layout Bangalore" ;
			
	
	//City(drop down)
	data[0][5] = "Bangalore";
			
	
	//State
	//data[0][6] = "Alaska";
	
	
	//Zip Code
	data[0][6] = "00000";
	
	
	//Country(dro down)
	//data[0][7] = "United States";
	
	
	//Mobile no.
	data[0][7] = "8971796001";
	
	
	//Assign Address
	data[0][8] = "Testing Address";
	
	
	return data;
	}
	

}
