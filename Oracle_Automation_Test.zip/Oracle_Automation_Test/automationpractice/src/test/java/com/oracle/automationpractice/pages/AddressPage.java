package com.oracle.automationpractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class AddressPage {
	
	
	
	WebDriver driver;
	
	 public AddressPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}


	 @FindBy(xpath=".//*[@name='processAddress']") 
	 public WebElement btn_proceedtocheckout;
	
	 
	

	public void proceedFromAddress() {
		Reporter.log("proceedFromAddress");
		
		btn_proceedtocheckout.click();
	}
		
}