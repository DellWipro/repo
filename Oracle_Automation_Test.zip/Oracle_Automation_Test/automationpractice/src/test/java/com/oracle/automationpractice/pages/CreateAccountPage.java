/**
 * 
 */
package com.oracle.automationpractice.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;

/**
 * @author Prateek Shrivastava
 *
 */
public class CreateAccountPage {
	
	WebDriver driver;
	
	 public CreateAccountPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	 
	 @FindBy(xpath=".//*[@id='email_create']") 
	 public WebElement txt_Email_Address;

	 @FindBy(xpath=".//*[@id='SubmitCreate']") 
	 public WebElement btn_CreateAccount;

	 @FindBy(xpath=".//*[@id='customer_firstname']") 
	 public WebElement txt_firstname;

	 @FindBy(xpath=".//*[@id='passwd']") 
	 public WebElement txt_password;
	 
	 @FindBy(xpath=".//*[@id='customer_lastname']") 
	 public WebElement txt_lastname;
	 

	 @FindBy(xpath=".//*[@id='days']") 
	 public WebElement txt_days;


	 @FindBy(xpath=".//*[@id='months']") 
	 public WebElement txt_months;


	 @FindBy(xpath=".//*[@id='years']") 
	 public WebElement txt_years;


	 @FindBy(xpath=".//*[@id='address1']") 
	 public WebElement txt_address;
	 

	 @FindBy(xpath=".//*[@id='city']") 
	 public WebElement txt_city;
	 
	 @FindBy(xpath=".//*[@id='id_state']") 
	 public WebElement txt_state;
	 
	 @FindBy(xpath=".//*[@id='postcode']") 
	 public WebElement txt_postcode;
	 
	 
	 @FindBy(xpath=".//*[@id='id_country']") 
	 public WebElement txt_country;
	 
	 @FindBy(xpath=".//*[@id='phone_mobile']") 
	 public WebElement txt_phone_mobile;
	 
	 @FindBy(xpath=".//*[@id='alias']") 
	 public WebElement txt_alias;

	 @FindBy(xpath=".//*[@id='submitAccount']") 
	 public WebElement txt_register;
	 
	 @FindBy(xpath=".//*[@class='logout']") 
	 public WebElement btn_logout;

	 
	 
	 /**
		 * enter the email address
		 * 
		 * @param emailaddress
		 */
		public void enterEmailAddress(String emailaddress) {
			Reporter.log("entering  email id");
			txt_Email_Address.sendKeys(emailaddress);
			
		}
			/**
			 * click on submit 
			 * 
			 */
			public void createAccount() {
				Reporter.log("Click on submit");
				
				btn_CreateAccount.click();;
				
			}

		
	
		/**
		 * enter first name
		 * 
		 */
		public void enterFirstName(String firstname) {
			Reporter.log("entering  firstname");
			txt_firstname.sendKeys(firstname);
			
		}
	
			

		/**
		 * enter last name
		 * 
		 */
		public void enterlastName(String lastname) {
			Reporter.log("entering  lastname");
			txt_lastname.sendKeys(lastname);
			
		}


		public void enterPassword(String passwd) {
			Reporter.log("entering  password");
			txt_password.sendKeys(passwd);
			
		}

		public void days() {
		Reporter.log(" entering date of birth");
				
		Select selectobj = new Select(txt_days);
		selectobj.selectByValue("10");
		
		}
		

		public void months() {
			
			Select selectobj = new Select(txt_months);
			selectobj.selectByIndex(2);;
			
		}


		public void years() {
			
			Select selectobj = new Select(txt_years);
			selectobj.selectByValue("1989");
			
		}

		
		public void enterAddress(String address) {
			Reporter.log("entering  address");
			
			txt_address.clear();
			txt_address.sendKeys(address);
		}
		 

		public void enterCity(String city) {
			Reporter.log("entering City");
			
			txt_city.sendKeys(city);
		}
		
		public void enterState() {
			Reporter.log("enterState");
			
			Select selectobj = new Select(txt_state);
			selectobj.selectByIndex(02);
			
			}
		
		
		public void enterPostCode(String postcode) {
			Reporter.log("postcode");
			
			txt_postcode.sendKeys(postcode);
		}
		
		public void enterCountry() {
			
		//	JavascriptExecutor js = (JavascriptExecutor) driver;
			//js.executeScript("window.scrollBy(0,1000)"); //Scroll vertically down by 1000 pixels	
			Reporter.log("entering Country");
			Select selectobj = new Select(txt_country);
			selectobj.selectByVisibleText("United States");;
			
		}
		
		public void enterMobileNo(String phone_mobile) {
			Reporter.log("entering phone_mobile");
			txt_phone_mobile.sendKeys(phone_mobile);
		}
		 
		
		public void enterAlias(String alias) {
			Reporter.log("alias");
			txt_alias.clear();
			txt_alias.sendKeys(alias);
		}
		 		
		public void register() {
			Reporter.log("Clicking on Register.");
			
			txt_register.click();;
		}


		public void getTitle() {

			System.out.println("Account Page Tittle Name is : "+driver.getTitle());;
			
		}
		public void logout() {
			System.out.println("Account Page Tittle Name is : "+driver.getTitle());;
			
			btn_logout.click();;
		}
			
}
