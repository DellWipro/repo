package com.oracle.automationpractice.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class DressesPage {
	

	WebDriver driver;
	
	 public DressesPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
	 @FindBy(xpath="(//*[@title='Dresses'])[2]") 
	 public WebElement btn_dress;
	 
	 @FindBy(xpath="(//*[contains(text(),'Printed Summer Dress')])[2]") 
	 public WebElement btn_printedSummerDress;
	 
	 
	 
	 

	 @FindBy(xpath="//*[contains(text(),'Add to cart')]") 
	 public WebElement btn_addtocart;
	 
	 @FindBy(xpath=".//*[@title='Proceed to checkout']") 
	 public WebElement btn_proceedtocheckout;
	 
	 
	 

	 public void addToCartDress() {
	 
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)"); //Scroll vertically down by 1000 pixels	

		Reporter.log("Choosing Printed Summer Dress");
		 
		btn_printedSummerDress.click();	
		
		js.executeScript("window.scrollBy(0,500)"); //Scroll vertically down by 1000 pixels	
		
		Reporter.log("Adding to cart");
		
		btn_addtocart.click();
		 
		btn_proceedtocheckout.click();
		 
		 
	 }

}
