package com.oracle.automationpractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.oracle.automationpractice.commonlibrary.LoadConfigurationPropertyUtility;

public class LoginPage {
	
	static String  path ="resources/login.properties";
	WebDriver driver;
	
	 public LoginPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
	
	public  String loginPagetitleName = "Login - My Store";


	 @FindBy(xpath=".//*[@id='email']") 
	 public WebElement txt_email;

	 @FindBy(xpath=".//*[@id='passwd']") 
	 public WebElement txt_password;

	 @FindBy(xpath=".//*[@id='SubmitLogin']") 
	 public WebElement btn_signin;

	 
	 public void login() {
		LoadConfigurationPropertyUtility.readFile(path);
		txt_email.sendKeys(LoadConfigurationPropertyUtility.emailId);
		txt_password.sendKeys(LoadConfigurationPropertyUtility.password);
		btn_signin.click();
	}
		
		

}
