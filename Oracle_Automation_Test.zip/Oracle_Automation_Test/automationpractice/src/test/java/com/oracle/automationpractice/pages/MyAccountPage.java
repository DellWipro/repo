package com.oracle.automationpractice.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class MyAccountPage {
	
	String myAccountPagetitleName = "My account - My Store";
	boolean flag;
	WebDriver driver;
	
	 public MyAccountPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
	 @FindBy(xpath=".//*[@class='logout']") 
	 public WebElement btn_logout;
	 
	 @FindBy(xpath="(//*[@title='Dresses'])[2]") 
	 public WebElement btn_dress;
	 			 
	 public void selectDress() {	
		Reporter.log("Choosing Dress");
		btn_dress.click();
	}
	
	
	 public boolean validationAfterRegistration() 
	 {
		 if(driver.getTitle().equalsIgnoreCase(myAccountPagetitleName)) {
			 
			 flag= true;
		 }
		 
		 else {
			 
			 flag= false;
		 }
		 return flag;
		 
	 }
	
	
		
}
