package com.oracle.automationpractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class OrderConfirmationPage {
	
	
	
	WebDriver driver;
	
	 public OrderConfirmationPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
	
	
	 @FindBy(xpath="//*[contains(@title,'Back to orders')]") 
	 public WebElement btn_backtoorders;
	

	 
public void backToOrders() {
	Reporter.log("backToOrders");
	 
	btn_backtoorders.click();
	 
	 
}	 



}
