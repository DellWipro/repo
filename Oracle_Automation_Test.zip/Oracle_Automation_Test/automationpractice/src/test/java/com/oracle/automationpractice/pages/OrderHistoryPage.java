package com.oracle.automationpractice.pages;

import java.awt.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

import junit.framework.Assert;

public class OrderHistoryPage {
	
	
	
	WebDriver driver;
	
	 public OrderHistoryPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}


	 @FindBy(xpath=".//*[@name='processCarrier']") 
	 public WebElement btn_proceedshipping;

	 @FindBy(xpath="//*[contains(@id,'order-list')]//tr[1]//td[1]") 
	 public WebElement table;


	 boolean tablePresentflag;

	 public boolean validateTable() {
		
		 int  listsize = driver.findElements(By.xpath("//*[contains(@id,'order-list')]//tr[1]//td[1]")).size();
		 
		 if(listsize>0) {
			 
			 tablePresentflag= true;
			 Reporter.log("History Table containing order is " +tablePresentflag);
		 }
			
		 else {
			 
			 tablePresentflag= false;
			 Reporter.log("History Table containing order is" +tablePresentflag);
			 
		 }
			 return tablePresentflag; 
			 
		 }
		 
	 }
	 




