package com.oracle.automationpractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class ShippingPage {
	
		
	WebDriver driver;
	
	 public ShippingPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}


	 @FindBy(xpath=".//*[@name='processCarrier']") 
	 public WebElement btn_proceedshipping;
	

	 @FindBy(xpath=".//*[@type='checkbox']")
	 public WebElement chckbox_termscondition;

	 


public void proceedFromShipping() {
	Reporter.log("proceedFromShipping");

	chckbox_termscondition.click();
	btn_proceedshipping.click();
	
}

}