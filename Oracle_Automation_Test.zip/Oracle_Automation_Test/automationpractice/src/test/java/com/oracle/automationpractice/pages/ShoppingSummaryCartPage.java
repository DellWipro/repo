package com.oracle.automationpractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class ShoppingSummaryCartPage {

	
	
	WebDriver driver;
	
	 public ShoppingSummaryCartPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	 
	 


	 @FindBy(xpath="(//*[contains(text(),'Proceed to checkout')])[2]") 
	 public WebElement btn_proceedtocheckout;
	

	public void proceedFromSummary() {
		Reporter.log("proceedFromSummary");
		
		btn_proceedtocheckout.click();
		
		
	}
}
