package com.oracle.automationpractice.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Reporter;

public class YourPaymentMethodPage {
	
	
	WebDriver driver;
	
	 public YourPaymentMethodPage(WebDriver driver) {
		this.driver = driver;
		 PageFactory.initElements(driver, this);
	}

	 @FindBy(xpath=".//*[@class='cheque']") 
	 public WebElement btn_cheque;

	public void selectPaymentMethod() {
	Reporter.log("selectPaymentMethod");
	btn_cheque.click();

}
}
