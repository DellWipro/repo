package com.oracle.automationpractice.testclass;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import com.oracle.automationpractice.commonlibrary.BaseClass;
import com.oracle.automationpractice.pages.AddressPage;
import com.oracle.automationpractice.pages.CreateAccountPage;
import com.oracle.automationpractice.pages.DressesPage;
import com.oracle.automationpractice.pages.LoginPage;
import com.oracle.automationpractice.pages.MyAccountPage;
import com.oracle.automationpractice.pages.OrderConfirmationPage;
import com.oracle.automationpractice.pages.OrderHistoryPage;
import com.oracle.automationpractice.pages.OrderSummaryPage;
import com.oracle.automationpractice.pages.ShippingPage;
import com.oracle.automationpractice.pages.ShoppingSummaryCartPage;
import com.oracle.automationpractice.pages.YourPaymentMethodPage;

public class OrderPlacement extends BaseClass {
  

	public String emailId;
	public String password;
	

	LoginPage loginPage;
	MyAccountPage myaccountPage;
	DressesPage dressesPage;
	ShoppingSummaryCartPage shoppingSummaryCartPage;
	AddressPage addressPage;
	ShippingPage shipingPage;
	YourPaymentMethodPage yourPaymentMethodPage;
	OrderSummaryPage orderSummaryPage;
	OrderConfirmationPage orderConfirmationPage;
	OrderHistoryPage orderHistoryPage ;
	
	@BeforeClass
	public void setUp() {
		loginPage= new LoginPage(driver);
		myaccountPage = new MyAccountPage(driver);
		dressesPage = new DressesPage(driver);
		shoppingSummaryCartPage = new ShoppingSummaryCartPage(driver);
		addressPage=new AddressPage(driver);
		shipingPage = new ShippingPage(driver);
		yourPaymentMethodPage = new YourPaymentMethodPage(driver);
		orderSummaryPage = new OrderSummaryPage(driver);
		orderConfirmationPage = new OrderConfirmationPage(driver);
		orderHistoryPage = new OrderHistoryPage(driver);
	}
	
	
	@Test
	public void placeOrder()
	{
		loginPage.login();
		
		myaccountPage.selectDress();
		
		dressesPage.addToCartDress();
		
		shoppingSummaryCartPage.proceedFromSummary();
		
		addressPage.proceedFromAddress();
		
		shipingPage.proceedFromShipping();
		
		yourPaymentMethodPage.selectPaymentMethod();
		
		orderSummaryPage.confirmOrder();
		
		orderConfirmationPage.backToOrders();
		
		
		//Validation Order History table , If returns true means , Order is available in table.
		Reporter.log("Validating Order History Table");
		
		Assert.assertEquals(true, orderHistoryPage.validateTable());
		
	}
	
}

	
	
	
	