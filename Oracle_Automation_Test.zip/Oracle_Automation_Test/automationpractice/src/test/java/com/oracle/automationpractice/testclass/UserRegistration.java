/**
 * 
 */
package com.oracle.automationpractice.testclass;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.oracle.automationpractice.commonlibrary.BaseClass;
import com.oracle.automationpractice.dataprovider.RegistrationDataProvider;
import com.oracle.automationpractice.pages.LoginPage;
import com.oracle.automationpractice.pages.MyAccountPage;
import com.oracle.automationpractice.pages.CreateAccountPage;

/**
 * @author Prateek Shrivastava
 *
 */

public class UserRegistration extends BaseClass {
	public CreateAccountPage createAccountPage ;
	LoginPage login;
	MyAccountPage myAccountPage;
	
	@BeforeClass
	public void setUp() {
		createAccountPage = new CreateAccountPage(driver);
		login= new LoginPage(driver);
		myAccountPage = new MyAccountPage(driver);
		
	}

	@Test(dataProvider = "registration", dataProviderClass = RegistrationDataProvider.class)
	public void registration(String firstName, String secondName, String email, String password, 
			String address, String city, String postcode,String  phone_mobile,String alias ) {
		
		
		createAccountPage.enterEmailAddress(email);
		
		createAccountPage.createAccount();
		
		createAccountPage.enterFirstName(firstName);
		
		createAccountPage.enterlastName(secondName);
		
		createAccountPage.enterPassword(password);
	
		createAccountPage.enterAddress(email);
		
		createAccountPage.days();
		
		createAccountPage.months();
		
		createAccountPage.years();
				
		createAccountPage.enterAddress(address);
		
		createAccountPage.enterCity(city);
		
		createAccountPage.enterState();
		
		createAccountPage.enterPostCode(postcode);
		
		createAccountPage.enterCountry();
		
		createAccountPage.enterMobileNo(phone_mobile);
		
		createAccountPage.enterAlias(alias);
		
		createAccountPage.register();
		
		Assert.assertEquals(true, myAccountPage.validationAfterRegistration());
		
		Reporter.log("Registration process is Completed.");
		
		createAccountPage.logout();
		
	}
	
}
